import glob,os,shutil
m="android/app/src/main/AndroidManifest.xml"
s=open(m,encoding="utf-8").read()
perms=["INTERNET","RECORD_AUDIO","MODIFY_AUDIO_SETTINGS","CAMERA","ACCESS_FINE_LOCATION","ACCESS_COARSE_LOCATION"]
add="".join('    <uses-permission android:name="android.permission.%s" />\n'%p for p in perms if 'android.permission.%s"'%p not in s)
add+='    <uses-feature android:name="android.hardware.microphone" android:required="false" />\n'
add+='    <uses-feature android:name="android.hardware.camera" android:required="false" />\n'
add+='    <uses-feature android:name="android.hardware.location.gps" android:required="false" />\n'
s=s.replace("<application",add+"    <application",1)
open(m,"w",encoding="utf-8").write(s)
res="android/app/src/main/res"
for d in glob.glob(res+"/mipmap-anydpi*"):shutil.rmtree(d)
for d in glob.glob("res-icons/mipmap-*"):
    dst=os.path.join(res,os.path.basename(d));os.makedirs(dst,exist_ok=True)
    for f in glob.glob(d+"/*.png"):shutil.copy(f,dst)
print("patched")
